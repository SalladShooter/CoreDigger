# CoreDigger

- Arrow Keys to move player and selector (Left, Right, Down)
- ENTER/SPACE to accept prompts

Something is afoot... A strange presence has brought you here to the caves. Your job, to find what is causing the disappearances. But wait, there are cave dwellers that don't want you to figure out the mystery and will try to take you down at all costs. 

Take your pick and mine and slash your way through the caves whilst finding upgrades that increase your capabilities. However, upgrading can have strange consequences... 

Can you figure out the mystery and survive the dangers? Or will you succumb to the horrors hiding inside?
